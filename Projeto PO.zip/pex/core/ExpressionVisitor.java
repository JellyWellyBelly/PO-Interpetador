package pex.core;

import pex.core.expression.*;
import pex.core.expression.literal.*;
import pex.core.expression.compositeexpression.*;
import pex.core.expression.compositeexpression.binaryexpression.*;
import pex.core.expression.compositeexpression.ternaryexpression.*;
import pex.core.expression.compositeexpression.unaryexpression.*;
import pex.core.expression.compositeexpression.variadicexpression.*;

import java.util.List;

public class ExpressionVisitor implements Visitor {

	public ExpressionVisitor() {

	}

	public Literal visit(Add expression) {
		
		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);
		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);
		return new IntegerLiteral(literal1.intValue() + literal2.intValue()); 
	}

	public Literal visit(And expression) {
		
		IntegerLiteral output = new IntegerLiteral(0);
		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);

		if (literal1.intValue() == 0) {
			output.setValue(0);
			return output;
		}

		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);

		if (literal2.intValue() == 0) {
			output.setValue(0);
			return output;
		}
		else {
			output.setValue(1);
			return output;
		}
	}

	public Literal visit(Div expression) {
		
		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);
		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);
		return new IntegerLiteral(literal1.intValue() / literal2.intValue()); 
	}

	public Literal visit(Eq expression) {
		
		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);
		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);
		int value;

		if(literal1.intValue() == literal2.intValue())
			value = 1;
		else
			value = 0;

		return new IntegerLiteral(value);
	}

	public Literal visit(Ge expression) {
		
		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);
		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);
		int value;

		if(literal1.intValue() >= literal2.intValue())
			value = 1;
		else
			value = 0;


		return new IntegerLiteral(value);
	}

	public Literal visit(Gt expression) {
		
		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);
		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);
		int value;

		if(literal1.intValue() > literal2.intValue())
			value = 1;
		else
			value = 0;

		return new IntegerLiteral(value);
	}

	public Literal visit(Le expression) {
		
		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);
		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);
		int value;

		if(literal1.intValue() <= literal2.intValue())
			value = 1;
		else
			value = 0;

		return new IntegerLiteral(value);
	}

	public Literal visit(Lt expression) {
		
		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);
		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);
		int value;
		
		if(literal1.intValue() < literal2.intValue())
			value = 1;
		else
			value = 0;

		return new IntegerLiteral(value);
	}

	public Literal visit(Mod expression) {
		
		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);
		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);
		return new IntegerLiteral(literal1.intValue() % literal2.intValue()); 
	}

	public Literal visit(Mul expression) {
		
		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);
		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);
		return new IntegerLiteral(literal1.intValue() * literal2.intValue()); 
	}

	public Literal visit(Ne expression) {

		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);
		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);
		int value;

		if(literal1.intValue() != literal2.intValue())
			value = 1;
		else
			value = 0;

		return new IntegerLiteral(value);
	}

	public Literal visit(Or expression) {

		IntegerLiteral output = new IntegerLiteral(0);
		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);

		if (literal1.intValue() != 0) {
			output.setValue(1);
			return output;
		}

		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);

		if (literal2.intValue() != 0) {
			output.setValue(1);
			return output;
		}
		else {
			output.setValue(0);
			return output;
		}
	}

	public Literal visit(Set expression) {
		
		Identifier identifier = (Identifier) expression.getFirstArgument();
		Literal literal = expression.getSecondArgument().accept(this);

		expression.getInterpreter().setIdentifierValue(identifier, literal);

		return literal;
	}

	public Literal visit(Sub expression) {
		
		IntegerLiteral literal1 = (IntegerLiteral) expression.getFirstArgument().accept(this);
		IntegerLiteral literal2 = (IntegerLiteral) expression.getSecondArgument().accept(this);
		return new IntegerLiteral(literal1.intValue() - literal2.intValue()); 
	}

	public Literal visit(While expression) {
		
		IntegerLiteral expCondition = (IntegerLiteral) expression.getFirstArgument().accept(this);

		while (expCondition.intValue() != 0) {
			expression.getSecondArgument().accept(this);
			expCondition = (IntegerLiteral) expression.getFirstArgument().accept(this);
		}

		return expCondition;
	}

	public Literal visit(If expression) {

		IntegerLiteral expCondition = (IntegerLiteral) expression.getFirstArgument().accept(this);

		if (((IntegerLiteral) visit(expCondition)).intValue() != 0) {
			return expression.getSecondArgument().accept(this);
		}
		else {
			return expression.getThirdArgument().accept(this);
		}
	}

	public Literal visit(Call expression) {
		Interpreter interpreter = expression.getInterpreter();
		StringLiteral literal = (StringLiteral) expression.getArgument().accept(this);

		return interpreter.getProgram(literal.stringValue()).evaluate();
	}

	public Literal visit(Neg expression){

		IntegerLiteral literal = (IntegerLiteral) expression.getArgument();
		literal.setValue((-1) * literal.intValue());
		return literal;
	}


	public Literal visit(Not expression){

		IntegerLiteral literal = (IntegerLiteral) expression.getArgument().accept(this);
		
		if(literal.intValue() == 0) {
			return new IntegerLiteral(1);
		}
		else {
			return new IntegerLiteral(0);
		}
	}

	public Literal visit(Print expression) {

		List<Expression> list = expression.getArguments();
		int size = list.size();
		String text = "";
		Literal lit = null;
		
		for(Expression exp : list) {
			try {
				lit = exp.accept(this);
				text += ((IntegerLiteral) lit).intValue();
			}
			catch(ClassCastException cc) {
				text += ((StringLiteral) lit).stringValue();
			}
		}

		expression.getApp().println(text);

		return lit;
	}

	public Literal visit(Seq expression) {

		List<Expression> list = expression.getArguments();
		int size = list.size();
		Literal lit = null;
		
		for(Expression exp : expression.getArguments()) {
			lit = exp.accept(this);
		}

		return lit;
	}

	public Literal visit(ReadI expression) {
		return new IntegerLiteral(expression.getApp().readInteger());
	}

	public Literal visit(ReadS expression) {
		return new StringLiteral(expression.getApp().readString());
	}

	public Literal visit(IntegerLiteral expression) {
		return expression;
	}

	public Literal visit(StringLiteral expression) {
		return expression;
	}

	public Literal visit(Identifier expression) {
		if(expression.getInterpreter().getIdentifier(expression) == null)
			return new IntegerLiteral(0);
		return expression.getInterpreter().getIdentifier(expression);
	}
}