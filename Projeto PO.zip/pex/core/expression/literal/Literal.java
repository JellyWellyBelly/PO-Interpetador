package pex.core.expression.literal;

public class Literal {
	
}