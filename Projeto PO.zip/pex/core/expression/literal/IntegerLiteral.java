package pex.core.expression.literal;

import pex.core.Visitor;

public class IntegerLiteral extends Literal {

	private int _value;

	public IntegerLiteral(int value) {
		_value = value;
	}

	public String getAsText() {
		return ("" + _value);
	}

	public int intValue() {
		return _value;
	}

	public void setValue(int value) {
		_value = value;
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}