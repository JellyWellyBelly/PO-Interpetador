package pex.core.expression.literal;

public class StringLiteral extends Literal {

	private String _value;

	public String getAsText() {
		return ("\"" + _value + "\"");
	}

	public String stringValue() {
		return _value;
	}
}