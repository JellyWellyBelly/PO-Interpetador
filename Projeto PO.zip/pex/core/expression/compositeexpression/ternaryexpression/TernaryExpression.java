package pex.core.expression.compositeexpression.ternaryexpression;

import pex.core.expression.Expression;
import pex.core.expression.compositeexpression.CompositeExpression;

public abstract class TernaryExpression extends CompositeExpression {
	
	private Expression _expression1;
	private Expression _expression2;
	private Expression _expression3;

	public TernaryExpression(Expression exp1, Expression exp2, Expression exp3) {
		_expression1 = exp1;
		_expression2 = exp2;
		_expression3 = exp3;
	}

	public Expression getFirstArgument() {
		return _expression1;
	}

	public Expression getSecondArgument() {
		return _expression2;
	}

	public Expression getThirdArgument() {
		return _expression3;
	}

	public String getAsText() {
		return _expression1.getAsText() + " " + _expression2.getAsText() + " " + _expression3.getAsText() + ")";
	}
}
