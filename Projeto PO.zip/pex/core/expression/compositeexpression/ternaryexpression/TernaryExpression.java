package pex.core.expression.compositeexpression.ternaryexpression;

public class TernaryExpression extends CompositeExpression {
	
	public Expression getFirstArgument() {

	}

	public Expression getSecondArgument() {
		
	}

	public Expression getThirdArgument() {
		
	}
}
