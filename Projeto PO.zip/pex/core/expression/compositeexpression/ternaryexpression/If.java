package pex.core.expression.compositeexpression.ternaryexpression;

import pex.core.Visitor;
import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public class If extends TernaryExpression {

	public If(Expression exp1, Expression exp2, Expression exp3) {
		super(exp1,exp2, exp3);
	}

	public String getAsText() {
		return "(if " + super.getAsText();
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}