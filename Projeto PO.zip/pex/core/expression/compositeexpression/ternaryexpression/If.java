package pex.core.expression.compositeexpression.ternaryexpression;

public class If extends TernaryExpression {

}
