package pex.core.expression.compositeexpression.binaryexpression;

public class BinaryExpression extends CompositeExpression {
	
	public Expression getFirstArgument() {

	}

	public Expression getSecondArgument() {
		
	}
}