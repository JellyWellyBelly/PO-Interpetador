package pex.core.expression.compositeexpression.binaryexpression;

import pex.core.expression.Expression;
import pex.core.expression.compositeexpression.CompositeExpression;

public abstract class BinaryExpression extends CompositeExpression {
	
	private Expression _expression1;
	private Expression _expression2;

	public BinaryExpression(Expression exp1, Expression exp2) {
		_expression1 = exp1;
		_expression2 = exp2;
	}

	public Expression getFirstArgument() {
		return _expression1;
	}

	public Expression getSecondArgument() {
		return _expression2;
	}
}