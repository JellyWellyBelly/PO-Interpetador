package pex.core.expression.compositeexpression.binaryexpression;

import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;
import pex.core.Visitor;

public class Add extends BinaryExpression {
	
	public Add(Expression exp1, Expression exp2) {
		super(exp1,exp2);
	}

	public String getAsText() {
		return "(add " + super.getAsText();
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}