package pex.core.expression.compositeexpression.binaryexpression;

public class Add extends BinaryExpression {

}