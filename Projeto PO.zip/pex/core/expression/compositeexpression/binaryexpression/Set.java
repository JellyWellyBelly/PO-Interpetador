package pex.core.expression.compositeexpression.binaryexpression;

import pex.core.Interpreter;
import pex.core.Visitor;
import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public class Set extends BinaryExpression {

	private Interpreter _interpreter;

	public Set(Expression exp1, Expression exp2, Interpreter interpreter) {
		super(exp1,exp2);
		_interpreter = interpreter;
	}

	public String getAsText() {
		return "(set " + super.getAsText();
	}

	public Interpreter getInterpreter() {
		return _interpreter;
	}
	
	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}