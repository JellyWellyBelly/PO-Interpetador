package pex.core.expression.compositeexpression.binaryexpression;

public class Set extends BinaryExpression {

}