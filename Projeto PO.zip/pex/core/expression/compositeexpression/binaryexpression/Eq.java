package pex.core.expression.compositeexpression.binaryexpression;

public class Eq extends BinaryExpression {

}