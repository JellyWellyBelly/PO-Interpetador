package pex.core.expression.compositeexpression.binaryexpression;

public class Div extends BinaryExpression {

}