package pex.core.expression.compositeexpression.binaryexpression;

import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public class Gt extends BinaryExpression {

	public Gt(Expression exp1, Expression exp2) {
		super(exp1,exp2);
	}

	public String getAsText() {
		return "(gt " + super.getFirstArgument().getAsText() + " " + super.getSecondArgument().getAsText() + ")";
	}

	public Literal evaluate() {
		// do later
		return null;
	}
}