package pex.core.expression.compositeexpression.binaryexpression;

public class Gt extends BinaryExpression {

}