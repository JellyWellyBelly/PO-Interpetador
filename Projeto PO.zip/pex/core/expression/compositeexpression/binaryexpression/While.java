package pex.core.expression.compositeexpression.binaryexpression;

import pex.core.Visitor;
import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public class While extends BinaryExpression {

	public While(Expression exp1, Expression exp2) {
		super(exp1,exp2);
	}

	public String getAsText() {
		return "(while " + super.getAsText();
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}