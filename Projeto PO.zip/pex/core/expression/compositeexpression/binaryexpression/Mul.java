package pex.core.expression.compositeexpression.binaryexpression;

public class Mul extends BinaryExpression {

}