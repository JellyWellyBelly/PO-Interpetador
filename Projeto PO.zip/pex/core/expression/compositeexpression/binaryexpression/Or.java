package pex.core.expression.compositeexpression.binaryexpression;

public class Or extends BinaryExpression {

}