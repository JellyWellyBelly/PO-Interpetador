package pex.core.expression.compositeexpression.binaryexpression;

import pex.core.Visitor;
import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public class Or extends BinaryExpression {

	public Or(Expression exp1, Expression exp2) {
		super(exp1,exp2);
	}

	public String getAsText() {
		return "(or " + super.getAsText();
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}