package pex.core.expression.compositeexpression.binaryexpression;

import pex.core.Visitor;
import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public class Ne extends BinaryExpression {

	public Ne(Expression exp1, Expression exp2) {
		super(exp1,exp2);
	}

	public String getAsText() {
		return "(ne " + super.getAsText();
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}