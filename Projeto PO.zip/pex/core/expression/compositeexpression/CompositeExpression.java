package pex.core.expression.compositeexpression;

import pex.core.expression.Expression;

public class CompositeExpression extends Expresion{
	
}