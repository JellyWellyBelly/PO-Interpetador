package pex.core.expression.compositeexpression;

import pex.AppIO;
import pex.app.App;
import pex.core.Visitor;
import pex.core.expression.literal.Literal;

public class ReadS extends CompositeExpression {

	private AppIO _app;

	public ReadS(App app) {
		_app = app;
	}

	public String getAsText() {
		return "(reads)";
	}

	public AppIO getApp() {
		return _app;
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}