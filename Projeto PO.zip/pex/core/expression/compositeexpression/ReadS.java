package pex.core.expression.compositeexpression;

public class ReadS {

	public String getAsText() {
		
	}
}