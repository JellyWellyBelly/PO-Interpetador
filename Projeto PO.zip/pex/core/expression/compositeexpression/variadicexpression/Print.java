package pex.core.expression.compositeexpression.variadicexpression;

import pex.core.Visitor;
import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

import pex.AppIO;

import java.util.List;

public class Print extends VariadicExpression {

	private AppIO _app;

	public Print(List<Expression> exps, AppIO app) {
		super(exps);
		_app = app;
	}

	public AppIO getApp() {
		return _app;
	}

	public String getAsText() {
		String text = "(print";

		for(Expression exp : super.getArguments())
			text += " " + exp.getAsText();
		text += ")";

		return text;
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}