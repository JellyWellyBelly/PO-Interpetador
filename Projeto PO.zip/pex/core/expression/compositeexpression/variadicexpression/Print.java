package pex.core.expression.compositeexpression.variadicexpression;

public class Print extends VariadicExpression {

}