package pex.core.expression.compositeexpression.variadicexpression;

public class Seq extends VariadicExpression {

}