package pex.core.expression.compositeexpression.variadicexpression;

import pex.core.Visitor;
import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

import java.util.List;

public class Seq extends VariadicExpression {

	public Seq(List<Expression> exps) {
		super(exps);
	}

	public String getAsText() {
		String text = "(seq";

		for(Expression exp : super.getArguments())
			text += " " + exp.getAsText();
		text += ")";

		return text;
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}