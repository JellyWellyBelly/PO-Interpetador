package pex.core.expression.compositeexpression.variadicexpression;

public class BinaryExpression extends CompositeExpression {
	
	public List<Expression> getArguments() {

	}
}