package pex.core.expression.compositeexpression.unaryexpression;

import pex.core.Visitor;
import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public class Neg extends UnaryExpression {

	public Neg(Expression exp) {
		super(exp);
	}

	public String getAsText() {
		return "(neg " + super.getAsText();
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}