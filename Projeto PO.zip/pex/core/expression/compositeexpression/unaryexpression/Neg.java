package pex.core.expression.compositeexpression.unaryexpression;

public class Neg extends UnaryExpression {

}