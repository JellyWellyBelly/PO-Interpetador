package pex.core.expression.compositeexpression.unaryexpression;

import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public class Neg extends UnaryExpression {

	public Neg(Expression exp) {
		super(exp);
	}

	public String getAsText() {
		return "(neg " + super.getArgument().getAsText() + ")";
	}

	public Literal evaluate() {
		// do later
		return null;
	}
}