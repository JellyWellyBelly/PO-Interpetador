package pex.core.expression.compositeexpression.unaryexpression;

import pex.core.Interpreter;
import pex.core.Visitor;
import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public class Call extends UnaryExpression {

	private Interpreter _interpreter;

	public Call(Expression exp, Interpreter interpreter) {
		super(exp);
		_interpreter = interpreter;
	}

	public String getAsText() {
		return "(call " + super.getAsText();
	}

	public Interpreter getInterpreter() {
		return _interpreter;
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}