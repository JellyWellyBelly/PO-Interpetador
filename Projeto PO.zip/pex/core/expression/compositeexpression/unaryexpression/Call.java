package pex.core.expression.compositeexpression.unaryexpression;

public class Class extends UnaryExpression {

}