package pex.core.expression.compositeexpression.unaryexpression;

import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public class Call extends UnaryExpression {

	public Call(Expression exp) {
		super(exp);
	}

	public String getAsText() {
		return "(call " + super.getArgument().getAsText() + ")";
	}

	public Literal evaluate() {
		// do later
		return null;
	}
}