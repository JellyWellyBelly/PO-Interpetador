package pex.core.expression.compositeexpression.unaryexpression;

import pex.core.Visitor;
import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public class Not extends UnaryExpression {
	
	public Not(Expression exp) {
		super(exp);
	}

	public String getAsText() {
		return "(not " + super.getAsText();
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}