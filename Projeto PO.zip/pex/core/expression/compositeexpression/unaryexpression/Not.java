package pex.core.expression.compositeexpression.unaryexpression;

public class Not extends UnaryExpression {

}