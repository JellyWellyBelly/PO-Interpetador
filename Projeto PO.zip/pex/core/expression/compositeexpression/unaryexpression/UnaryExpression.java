package pex.core.expression.compositeexpression.unaryexpression;

import pex.core.expression.Expression;
import pex.core.expression.compositeexpression.CompositeExpression;

public abstract class UnaryExpression extends CompositeExpression {
	
	private Expression _expression;

	public UnaryExpression(Expression exp) {
		_expression = exp;
	}

	public Expression getArgument() {
		return _expression;
	}

	public String getAsText() {
		return _expression.getAsText() + ")";
	}
}