package pex.core.expression.compositeexpression.unaryexpression;

public class UnaryExpression extends CompositeExpression {
	
	public Expression getArgument() {

	}
}