package pex.core.expression;

import pex.core.expression.literal.Literal;

public abstract class Expression {
	
	public abstract String getAsText();

	public abstract Literal evaluate();
}