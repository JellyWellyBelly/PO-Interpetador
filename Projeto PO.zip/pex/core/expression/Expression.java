package pex.core.expression;

import pex.core.Visitor;
import pex.core.expression.literal.Literal;

import java.io.Serializable;

public abstract class Expression implements Serializable {
	
	public abstract String getAsText();

	public abstract Literal accept(Visitor visitor);
}