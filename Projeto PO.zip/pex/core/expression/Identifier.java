package pex.core.expression;

public class Identifier {

	private String _name;

	public String getAsText() {

	}
}
