package pex.core.expression;

import pex.core.expression.literal.Literal;

public class Identifier extends Expression {

	private String _name;
	private Literal _value;

	public Identifier(String name) {
		_name = name;
	}

	public void setValue(Literal value) {
		_value = value;
	}

	public Literal getValue() {
		return _value;
	}

	public String getAsText() {
		return _name;
	}

	public Literal evaluate() {
		// do later
		return null;
	}
}
