package pex.core.expression;

import pex.core.Interpreter;
import pex.core.Visitor;
import pex.core.expression.literal.Literal;

import java.lang.ClassCastException;

public class Identifier extends Expression {

	private String _name;
	private Interpreter _interpreter;

	public Identifier(String name, Interpreter interpreter) {
		_name = name;
		_interpreter = interpreter;
	}

	public String getAsText() {
		return _name;
	}

	public int hashCode() {
		return this.getAsText().hashCode();
	}

	public boolean equals(Object obj) {
		try {
			return this.getAsText().equals(((Identifier) obj).getAsText());
		}
		catch(ClassCastException cc) {
			return false;
		}
	}

	public Interpreter getInterpreter() {
		return _interpreter;
	}

	public Literal accept(Visitor visitor) {
		return visitor.visit(this);
	}
}
