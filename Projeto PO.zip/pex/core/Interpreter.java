package pex.core;

import pex.app.App;
import pex.core.expression.Identifier;
import pex.core.expression.literal.Literal;

import java.io.Serializable;

import java.util.HashMap;

public class Interpreter implements Serializable {

	private HashMap<String, Program> _programs;
	private HashMap<Identifier, Literal> _identifiers;
	private App _app;
	
	public Interpreter(App app) {
		_app = app;
		_programs = new	HashMap<String, Program>();
		_identifiers = new HashMap<Identifier, Literal>();
	}
	
	public void setIdentifierValue(Identifier id, Literal value) {
		_identifiers.put(id, value);
	}
	
	public Literal getIdentifier(Identifier id) {
		return _identifiers.get(id);
	}
	
	public void addProgram(Program program) {
		_programs.put(program.getName(), program);
	}
	
	public void removeProgram(String name) {
		_programs.remove(this.getProgram(name));
	}
	
	public Program getProgram(String name) {
		return _programs.get(name);
	}
	
	public App getAppIO() {
		return _app;
	}
}