package pex.core;

import pex.app.App;

public class Interpreter {

	private ArrayList<Program> _programs;
	private App _app;
	private HashMap<Identifier> _identifiers;

	public Interpreter(App app) {
		_app = app;		
	}

	public void setIdentifierValue(Identifier id, Literal value) {
		_identifiers.put(id, value);
	}

	public Literal getIdentifier(Identifier id) {
		Literal ident = _identifiers.get(id);
		return ident;
	}

	public void addProgram(Program program) {
		_programs.add(program);
	}

	public void removeProgram(String name) {
		_programs.remove(this.getProgram(name));
	}

	public Program getProgram(String name) {
		for(Program prog : _programs)
			if(name.equals(prog.getName()))
				return prog;
		return null;
	}

	public App getAppIO() {
		return _app;
	}
}