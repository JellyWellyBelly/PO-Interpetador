package pex.core;

import pex.app.App;
import pex.core.expression.Identifier;
import pex.core.expression.literal.Literal;

import java.util.ArrayList;
import java.util.HashMap;

public class Interpreter {

	private ArrayList<Program> _programs;
	private App _app;
	private HashMap<String, Identifier> _identifiers;

	public Interpreter(App app) {
		_app = app;		
	}

	public void setIdentifierValue(Identifier id, Literal value) {
		id.setValue(value);
		_identifiers.put(id.getAsText(), id);
	}

	public Literal getIdentifier(Identifier id) {
		return _identifiers.get(id.getAsText()).getValue();
	}

	public void addProgram(Program program) {
		_programs.add(program);
	}

	public void removeProgram(String name) {
		_programs.remove(this.getProgram(name));
	}

	public Program getProgram(String name) {
		for(Program prog : _programs)
			if(name.equals(prog.getName()))
				return prog;
		return null;
	}

	public App getAppIO() {
		return _app;
	}
}