package pex.core;

import pex.app.App;
import pex.parser.*;
import pex.app.evaluator.EvaluatorMenu;

import java.io.Serializable;
import java.io.IOException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;

import pt.utl.ist.po.ui.Menu;
import pt.utl.ist.po.ui.InvalidOperation;

public class InterpreterHandler implements Serializable {
	
	private Interpreter _interpreter;
	private App _app;
	private String _fileName = null;
	private boolean _changes = false;

	public InterpreterHandler(App app) {
		_app = app;
		_changes = true;
	}

	public String getFileName() {
		return _fileName;
	}

	public boolean getChange() {
		return _changes;
	}

	public Interpreter getInterpreter() {
		return _interpreter;
	}

	public void newInterpreter() {
		_interpreter = new Interpreter(_app);
		_changes = true;
	}
	
	public void saveInterpreter() throws IOException {

		if(!(_fileName.equals(null))) {
			FileOutputStream fileOut = new FileOutputStream(_fileName);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(_interpreter);
			out.close();
			fileOut.close();
			_changes = false;
      	}
      	else {
      		throw new IOException();
      	}
	}

	public void saveAsInterpreter(String name) throws IOException {
		_fileName = name;
		File file = new File(_fileName);
		
		try {
			file.createNewFile();
			this.saveInterpreter();
		}
		catch(IOException fnf) {
			throw new IOException();
		}

	}

	public void loadInterpreter(String fileName) throws IOException, ClassNotFoundException ,FileNotFoundException {

		if(new File(fileName).exists()) {
			try {
				FileInputStream fileIn = new FileInputStream(fileName);
				ObjectInputStream inob = new ObjectInputStream(fileIn);
				_interpreter = (Interpreter)inob.readObject();
				inob.close();
				fileIn.close();
			}
			catch(IOException fnf) {
				throw new IOException();
			}
			catch(ClassNotFoundException cnf) {
				throw new ClassNotFoundException();
			}
			_changes = false;
		}
		else {
			throw new FileNotFoundException();
		}
	}

	public void addProgram(String name) {
		Program program = new Program(name, _interpreter);
		
		if(!(_interpreter.getProgram(name)).equals(null))
			_interpreter.removeProgram(name);
		_interpreter.addProgram(program);
	}

	public void readProgram(String fileName) throws InvalidOperation, FileNotFoundException {

		if(new File(fileName).exists()) {
			try {
				NewParser parser = new NewParser();			
				Program program = parser.parseFile(fileName, fileName, this);
        		_interpreter.addProgram(program);
        	}
        	catch(ParserException ps) {
        		throw new InvalidOperation();
        	}
		}
		else {
			throw new FileNotFoundException();
		}
    }

    public void writeProgram(String programName, String fileName) throws IOException {
    	
    	if(_interpreter.getProgram(programName) != null) {
    		File file = new File(fileName);
    		file.createNewFile();

			Program program = _interpreter.getProgram(programName);
    		String text = program.getAsText();
    		PrintWriter printWriter = new PrintWriter(file);
    		printWriter.print(text);
    		
    		printWriter.close();
    	}
    	else {
    		throw new IOException();
    	}
    }

    // VER ISTO, ANDRE DIZ Q QUEBRA ABSTRAÇAO
    public void editProgram(String programName) throws IOException {
    	if(_interpreter.getProgram(programName) != null) {
    		Program program = _interpreter.getProgram(programName);
    		Menu evaluator = new EvaluatorMenu(program);
    		evaluator.open();
    	}
    	else {
    		throw new IOException();
    	}
    }
}