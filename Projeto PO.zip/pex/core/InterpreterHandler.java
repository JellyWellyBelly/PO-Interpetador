package pex.core;

import pex.core.Interpreter;
import pex.app.App;

import java.io.Serialization;
import java.io.IOException;
import java.io.InvalidOperation;
import java.io.File;

public class InterpreterHandler {
	
	private Interpreter _interpreter;
	private App _app;
	private String _fileName;
	private boolean _changes = true;

	public InterpreterHandler(App app) {
		_app = app;
		_changes = true;
	}

	public String getFileName() {
		return _fileName;
	}

	public boolean getChange() {
		return _changes;
	}

	public Interpreter getInterpreter() {
		return _interpreter;
	}

	// criar inter
	public void newInterpreter() {
		_interpreter = new Interpreter(_app);
		_changes = true;
	}
	
	// guardar inter
	public void saveInterpreter() throws InvalidOperation {
		_changes = false;

		// ver se ta bem...
		try {
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(this.getFileName()));
			out.writeObject(this.getInterpreter());
			out.close();
      	}
      	catch(IOException i) {
        	throw i;
      	}
      	f.close();
	}

	// guardar como inter
	public void saveAsInterpreter(String name) {
		_fileName = name;
		File f = new File(_fileName);
		this.saveInterpreter();
	}

	// carregar inter
	public Interpreter loadInterpreter(String name) throws InvalidOperation {
		_changes = true;


		// ver se ta bem...
		try {
			ObjectInputStream inob = new ObjectInputStream(new FileInputStream(name));
			_interpreter = (Interpreter)inob.readObject();
			f.close();
		}
		catch(IOException e) {
			throw e;
		}
		catch(ClassNotFoundException e) {
			// do something
		}

		return interp;
	}

	public void addProgram(String name) {
		Program program = new Program(name);
		
		if(!(_interpreter.getProgram(name)).equals(null))
			_interpreter.removeProgram(name);
		_interpreter.addProgram(program);
	}

	public void readProgram(String name) throws InvalidOperation {
		NewParser parser = new NewParser();
		

		// ver se ta bem...
		try {
			Program program = parser.parseFile(_fileName, name);
            _interpreter.add(program);
        }
        catch(IOException e) {
        	throw e;
        }
        catch(ClassNotFoundException e) {
        	// do shit
        }
    }

    public void writeProgram(Program program, String filename) {
    	File file = new File(filename);

    	String text = program.getAsText();
    	PrintWriter printWriter = new PrintWriter(file);
    	file.close();
    }
}