package pex.core;

/**
 * @author Tomas Carrasco
 * @author Miguel Viegas
 * @version Intermediate Version
 */

import pex.core.Interpreter;
import pex.core.expression.Expression;
import pex.core.expression.Identifier;
import pex.core.expression.literal.Literal;
import pex.core.IdentifierVisitor;

import java.io.Serializable;

import java.util.Set;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Program implements Serializable {

	/**
	 * Name of the program.
	 */
	private String _name;
	
	/**
	 * Interpreter associated with the program.
	 */
	private Interpreter _interpreter;
	
	/**
	 * Array of Expressions of the program.
	 */
	private ArrayList<Expression> _expressions;




	/**
	 * Overloaded Constructor
	 * @param name Name of the program.
	 * @param interpreter Interpreter of the program.
	 */
	public Program(String name, Interpreter interpreter) {
		_name = name;
		_interpreter = interpreter;
		_expressions = new ArrayList<Expression>();
	}


	/**
	 * Gets the name of the program.
	 * @return Name of the program.
	 */
	public String getName() {
		return _name;
	}


	public Interpreter getInterpreter() {
		return _interpreter;
	}

	/**
	 * Gets the ArrayList of Expression's of the program.
	 * @return ArrayList of Expression's
	 */
	public ArrayList<Expression> getExpressions() {
		return _expressions;
	}


	/**
	 * Overrides the list of Expressions with a given one.
	 * @param expressions New list of Expression's.
	 */
	public void set(Collection<Expression> expressions) {
		_expressions.addAll(expressions);
	}


	/**
	 * Adds in a given position a new Expression.
	 * @param idx Position of the new Expression.
	 * @param expression New Expression.
	 */
	public void add(int idx, Expression expression) {
		_expressions.add(idx, expression);
	}


	/**
	 * Replaces an Expression of a given position with a new one.
	 * @param idx Position of the new Expression.
	 * @param expression New Expression.
	 */
	public void replace(int idx, Expression expression) {
		_expressions.set(idx, expression);
	}


	/**
	 * Overrides an Indentifier's value with a new one.
	 * @param id Name of Identifier.
	 * @param value Identifier's new value.
	 */
	public void setIdentifierValue(Identifier id, Literal value) {
		_interpreter.setIdentifierValue(id, value);
	}


	/**
	 * Gets an Identifier's value.
	 * @param id Name of Identifier.
	 * @return Returns the value of the Indetifier given.
	 */
	public Literal getIdentifierValue(Identifier id) {
		return _interpreter.getIdentifier(id);
	}


	/**
	 * Does nothing for now.
	 * @return Always returns 'null'.
	 */
	public Literal evaluate() {

		Visitor visitor = new ExpressionVisitor();
		int size = _expressions.size();
		Literal lit = null;

		for(Expression exp : _expressions) {
			lit = exp.accept(visitor);
		}

		return lit;

	}

	public String showAllIdentifiers() {

		IdentifierVisitor visitor = new IdentifierVisitor();
		String text = "";

		for(Expression exp : _expressions) {
			exp.accept(visitor);
		}

		Set<String> set = (visitor.getAllIdentifiers()).keySet();

		for(String str : set)
			text += str + "\n";
	
		return text;
	}

	public String showUnitializedIdentifiers() {

		IdentifierVisitor visitor = new IdentifierVisitor();
		String text = "";

		for(Expression exp : _expressions) {
			exp.accept(visitor);
		}

		Set<String> set = (visitor.getUnitializedIdentifiers()).keySet();

		for(String str : set)
			text += str + "\n";
	
		return text;
	}


	/**
	 * Returns the program in a String format.
	 * @return The String representation of the program
	 */
	public String getAsText() {
		String text = "";
		for(Expression expression : _expressions)
			text += expression.getAsText() + "\n";
		return text;
	}


	/**
	 * Gets an interpreter's program.
	 * @param name Name of the program.
	 * @return Returns the Program with the name "name". Otherwise returns 'null'.
	 */
	public Program getProgram(String name) {
		return _interpreter.getProgram(name);
	}
}