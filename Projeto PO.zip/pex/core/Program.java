package pex.core;

import pex.core.Interpreter;
import pex.core.expression.Expression;
import pex.core.expression.Identifier;
import pex.core.expression.literal.Literal;

import java.util.ArrayList;
import java.util.Collection;

public class Program {

	private String _name;
	private Interpreter _interpreter;
	private ArrayList<Expression> _expressions;

	public Program(String name, Interpreter interpreter) {
		_name = name;
		_interpreter = interpreter;
	}

	public String getName() {
		return _name;
	}

	public ArrayList<Expression> getExpressions() {
		return _expressions;
	}

	public void set(Collection<Expression> expressions) {
		_expressions.addAll(expressions);
	}

	public void add(int idx, Expression expression) {
		_expressions.add(idx, expression);
	}

	public void replace(int idx, Expression expression) {
		_expressions.set(idx, expression);
	}

	public void setIdentifierValue(Identifier id, Literal value) {
		_interpreter.setIdentifierValue(id, value);
	}

	public Literal getIdentifierValue(Identifier id) {
		return _interpreter.getIdentifier(id);
	}

	public Literal execute() {
		// do later
		return null;
	}

	public String getAsText() {
		String text = "";

		for(Expression expression : _expressions)
			text += expression.getAsText();
		return text;
	}

	public Program getProgram(String name) {
		return _interpreter.getProgram(name);
	}
}