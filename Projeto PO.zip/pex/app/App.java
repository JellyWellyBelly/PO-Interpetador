package pex.app;

import pex.AppIO;
import pex.parser.ParserException;
import pex.app.main.MainMenu;

import pex.parser.NewParser;
import pex.core.*;

import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;
import pt.utl.ist.po.ui.InputInteger;
import pt.utl.ist.po.ui.Display;

/**
 * This is a sample client for the expression evaluator.
 * It uses a text-based user interface.
 */
public class App implements AppIO {
    
    //private NewParser _parser;
    //private InterpreterHandler _handler = null;

    public App() {
       //_handler = new InterpreterHandler(this);
    }

    /**
     * Writes a string to be presented to the user.
     *
     * @param str the string to write
     **/
    public void println(String str) {
        Display display = new Display();
        display.add(str);
        display.display();
    }

    /**
     * Reads a string inputed by the user.
     *
     * @return the string written by the user.
     **/
    public String readString() {
        Form form = new Form();
        InputString input = new InputString(form, null);
        form.parse();
        return input.value();
    }

    /**
     * Reads an integer inputed by the user.
     *
     * @return the number written by the user.
     **/
    public int readInteger() {
        Form form = new Form();
        InputInteger input = new InputInteger(form, null);
        form.parse();
        return input.value();   
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        
        App app = new App();
        InterpreterHandler handler = new InterpreterHandler(app); 
        NewParser parser = new NewParser();

        String datafile = System.getProperty("import"); //$NON-NLS-1$
        if (datafile != null) {
            try {
                Program program = parser.parseFile(datafile, datafile, handler);
                handler.getInterpreter().addProgram(program);
            } 
            catch (ParserException e) {
                e.printStackTrace();
            }
        }
        
        MainMenu menu = new MainMenu(handler);
        menu.open();
    }
}
