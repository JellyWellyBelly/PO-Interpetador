package pex.app.main;

import java.io.FileNotFoundException;
import java.io.IOException;

import pex.core.InterpreterHandler;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Display;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;
import pt.utl.ist.po.ui.InvalidOperation;

/**
 * Open existing interpreter.
 */
public class Open extends Command<InterpreterHandler> {
    /**
     * @param receiver
     */
    public Open(InterpreterHandler receiver) {
        super(Label.OPEN, receiver);
    }

    /** @see pt.tecnico.po.ui.Command#execute() */
    @Override
    public final void execute() throws InvalidOperation {
        Message message = new Message();
        Form form = new Form();

        if((entity().getFileName()).equals(null)) {
            InputString input = new InputString(form, message.openFile());
            form.parse();
            String name = input.value();
        }

        if((entity().getFileName()).equals(name)) {
            entity().loadInterpreter(name);
        }
        else {
            Display display = new Display();
            display.add(message.fileNotFound(name));
            display.display();
        }
    }
}
