package pex.app.main;

import java.io.FileNotFoundException;

import pex.core.InterpreterHandler;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Display;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;

/**
 * Open existing interpreter.
 */
public class Open extends Command<InterpreterHandler> {
    /**
     * @param receiver
     */
    public Open(InterpreterHandler receiver) {
        super(Label.OPEN, receiver);
    }

    /** @see pt.tecnico.po.ui.Command#execute() */
    @Override
    public final void execute() {
        Form form = new Form();
        InputString input = new InputString(form, Message.openFile());
        form.parse();
        
        try {
            entity().loadInterpreter(input.value());
        }

        catch(Exception fnf) {
            Display display = new Display();
            display.add(Message.fileNotFound(input.value()));
            display.display();
        }
    }
}
