package pex.app.main;

import java.io.IOException;

import pex.core.InterpreterHandler;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;
import pt.utl.ist.po.ui.InvalidOperation;

/**
 * Save to file under current name (if unnamed, query for name).
 */
public class Save extends Command<InterpreterHandler> {
    /**
     * @param receiver
     */
    public Save(InterpreterHandler receiver) {
        super(Label.SAVE, receiver);
    }

    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() throws InvalidOperation {
        
        // ver esta merda... deve estar mal e não tou a ver como se resolve...

        if(entity().getChange() == true) {
            try {
                entity().saveInterpreter();
            }
            catch(IOException) {
                Form form = new Form();
                Message message = new Message();
                InputString input = new InputString(form, message.newSaveAs());
                form.parse();
                String name = input.value();
                
                try {
                    entity().saveAsInterpreter(name);
                }
                catch(IOException) {
                    throw new InvalidOperationException();
                }
            }
           catch(ClassNotFoundException) {
                // gotta do this shit
            }
        }
    }
}
