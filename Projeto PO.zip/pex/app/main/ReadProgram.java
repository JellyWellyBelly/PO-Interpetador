package pex.app.main;

import pex.parser.NewParser;
import pex.core.InterpreterHandler;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Display;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;

/**
 * Read existing program.
 */
public class ReadProgram extends Command<InterpreterHandler> {
    /**
     * @param receiver
     */
    public ReadProgram(InterpreterHandler receiver) {
        super(Label.READ_PROGRAM, receiver);
    }

    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() {
        Message message = new Message();
        Form form = new Form();
        InputString input = new InputString(form, message.programFileName());
        form.parse();
        String name = input.value();

        entity().readProgram(name);
    }
}
