package pex.app.main;

import pex.parser.NewParser;
import pex.core.InterpreterHandler;

import java.io.FileNotFoundException;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Display;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;

/**
 * Read existing program.
 */
public class ReadProgram extends Command<InterpreterHandler> {
    /**
     * @param receiver
     */
    public ReadProgram(InterpreterHandler receiver) {
        super(Label.READ_PROGRAM, receiver);
    }

    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() {
        Form form = new Form();
        InputString input = new InputString(form, Message.programFileName());
        form.parse();

        try {
            entity().readProgram(input.value());
        }
        catch(Exception fnf) {
            Display display = new Display();
            display.add(Message.fileNotFound(input.value()));
            display.display();
        }
    }
}
