package pex.app.main;

import java.io.IOException;

import pex.core.InterpreterHandler;
import pex.core.Program;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Display;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;

/**
 * Write (save) program to file.
 */
public class WriteProgram extends Command<InterpreterHandler> {
    /**
     * @param receiver
     */
    public WriteProgram(InterpreterHandler receiver) {
        super(Label.WRITE_PROGRAM, receiver);
    }

    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() {
        Form form = new Form();
        InputString inputProgram = new InputString(form, Message.requestProgramId());
        InputString inputFile = new InputString(form, Message.programFileName());
        form.parse();
        
        try {
            entity().writeProgram(inputProgram.value(), inputFile.value());
        }
        
        catch (IOException io) {
            Display display = new Display();
            display.add(Message.noSuchProgram(inputProgram.value()));
            display.display();
        }
    }
}
