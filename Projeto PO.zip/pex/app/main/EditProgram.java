package pex.app.main;

import pex.core.InterpreterHandler;
import pex.core.Program;

import pex.app.evaluator.EvaluatorMenu;
import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.InputString;
import pt.utl.ist.po.ui.Menu;
import pt.utl.ist.po.ui.Display;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InvalidOperation;

/**
 * Open menu for managing programs.
 */
public class EditProgram extends Command<InterpreterHandler> {

    /**
     * @param receiver
     */
    public EditProgram(InterpreterHandler receiver) {
        super(Label.MANAGE_PROGRAM, receiver);
    }

    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() throws InvalidOperation {
        Message message = new Message();
        Form form = new Form();
        InputString input = new InputString(form, message.requestProgramId());
        form.parse();
        String name = input.value();
        
        Program program = (entity().getInterpreter()).getProgram(name);
        
        if(!(program.equals(null))) {
            Menu evaluator = new EvaluatorMenu(program);
        }

        else {
            Display display = new Display();
            display.add(message.noSuchProgram());
            display.display();
        }
    }
}
