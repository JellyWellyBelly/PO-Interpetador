package pex.app.main;

import pex.core.InterpreterHandler;
import pex.core.Program;
import pex.app.evaluator.EvaluatorMenu;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.InputString;
import pt.utl.ist.po.ui.Menu;
import pt.utl.ist.po.ui.Display;
import pt.utl.ist.po.ui.Form;


/**
 * Open menu for managing programs.
 */
public class EditProgram extends Command<InterpreterHandler> {

    /**
     * @param receiver
     */
    public EditProgram(InterpreterHandler receiver) {
        super(Label.MANAGE_PROGRAM, receiver);
    }

    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() {
        Form form = new Form();
        InputString input = new InputString(form, Message.requestProgramId());
        form.parse();

        Program program = entity().getInterpreter().getProgram(input.value());

        if (program != null) {
            Menu evaluator = new EvaluatorMenu(program);
            evaluator.open();
        }
        else {
            Display display = new Display();
            display.add(Message.noSuchProgram(input.value()));
            display.display();
        }
    }
}