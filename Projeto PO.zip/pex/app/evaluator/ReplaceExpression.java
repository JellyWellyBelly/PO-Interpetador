package pex.app.evaluator;

import pex.app.BadExpressionException;
import pex.app.BadPositionException;

import pex.core.Program;

import pex.parser.NewParser;
import pex.parser.ParserException;

import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;
import pt.utl.ist.po.ui.InputInteger;

/**
 * Replace expression in program.
 */
public class ReplaceExpression extends ProgramCommand {
    /**
     * @param receiver
     */
    public ReplaceExpression(Program receiver) {
        super(Label.REPLACE_EXPRESSION, receiver);
    }

    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() throws BadExpressionException, BadPositionException {
        Form form = new Form();
        InputInteger inputI = new InputInteger(form, Message.requestPosition());
        InputString inputS = new InputString(form, Message.requestExpression());
        form.parse();

        try {
            if(inputI.value() < 0 || inputI.value() >= entity().getExpressions().size()) {
                throw new BadPositionException(inputI.value());   
            }

            NewParser parser = new NewParser(entity().getInterpreter());
            entity().replace(inputI.value(), parser.parseString(inputS.value(), entity()));
        }
        catch(ParserException p) {
            throw new BadExpressionException("Bad expression found");
        }
    }
}