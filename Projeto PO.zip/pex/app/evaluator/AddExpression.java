package pex.app.evaluator;

import pex.parser.NewParser;
import pex.parser.ParserException;

import pex.app.BadExpressionException;
import pex.app.BadPositionException;

import pex.core.Program;

import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;
import pt.utl.ist.po.ui.InputInteger;

/**
 * Add expression.
 */
public class AddExpression extends ProgramCommand {
    /**
     * @param receiver
     */
    public AddExpression(Program receiver) {
        super(Label.ADD_EXPRESSION, receiver);
    }
    
    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() throws BadExpressionException, BadPositionException {

        Form form = new Form();
        InputInteger inputI = new InputInteger(form, Message.requestPosition());
        InputString inputS = new InputString(form, Message.requestExpression());
        form.parse();

        try {
            if(inputI.value() < 0 || inputI.value() > entity().getExpressions().size())
                throw new BadPositionException(inputI.value());
            
            NewParser parser = new NewParser(entity().getInterpreter());
            entity().add(inputI.value(), parser.parseString(inputS.value(), entity()));
        }
        catch(ParserException p) {
            throw new BadExpressionException("Bad expression found");
        }
    }
}
