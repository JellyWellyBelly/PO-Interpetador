package pex.app.main;

import pex.core.InterpreterHandler;
import pex.app.main.Message;
import pt.utl.ist.po.ui.Command;

/**
 * Command for creating a new interpreter.
 */
public class New extends Command<InterpreterHandler> {
    /**
     * @param receiver
     */
    public New(InterpreterHandler receiver) {
        super(Label.NEW, receiver);
    }

    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() {
        entity().newInterpreter();
    }
}
