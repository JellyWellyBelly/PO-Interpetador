package pex.app.main;

import java.io.FileNotFoundException;
import java.io.IOException;

import pex.app.core.InterpreterHandler;
import pex.app.main.Message;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Display;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;
import pt.utl.ist.po.ui.InvalidOperation;

/**
 * Open existing interpreter.
 */
public class Open extends Command<InterpreterHandler> {
    /**
     * @param receiver
     */
    public Open(InterpreterHandler receiver) {
        super(Label.OPEN, receiver);
    }

    /** @see pt.tecnico.po.ui.Command#execute() */
    @Override
    public final void execute() {
        Form form = new Form();
        InputString inS = new InputString(form, Message.openFile())
        form.parse();
        try {
            entity().openInterpreter(inS.value)
        }        
        catch (FileNotFoundException){
            Display display = new Display();
            display.add(Message.fileNotFound(inS.value()));
            display.display();
        }
    }
}
