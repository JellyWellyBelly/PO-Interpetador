package pex.app.main;

import pex.app.main.InterpreterHandler;
import pex.app.main.Message;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Display;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;

/**
 * Read existing program.
 */
public class ReadProgram extends Command<InterpreterHandler> {
    /**
     * @param receiver
     */
    public ReadProgram(InterpreterHandler receiver) {
        super(Label.READ_PROGRAM, receiver);
    }

    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() {
        try {
            Form form = new Form();
            InputString inS = new InputString(form, Message.programFileName());
            form.parse();
            entity().readProgram(inS.value);
        } catch (IOException) {
            Display display = new Display();
            display.add(Message.fileNotFound(inS.value + "txt"));
            display.display();
        }
    }
}