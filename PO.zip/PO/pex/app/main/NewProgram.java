package pex.app.main;

import pex.app.core.InterpreterHandler;
import pex.app.main.Message;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;

/**
 * Create new program.
 */
public class NewProgram extends Command<InterpreterHandler> {

    /**
     * @param receiver
     */
    public NewProgram(InterpreterHandler receiver) {
        super(Label.NEW_PROGRAM, receiver);
    }

    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() {
        Form form = new Form();
        InputString inS = new InputString(form, Message.requestProgramId());
        form.parse();
        entity().createNewProgram(inS.value);
    }
}
