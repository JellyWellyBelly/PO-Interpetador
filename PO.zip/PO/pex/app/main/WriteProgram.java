package pex.app.main;

import java.io.IOException;
import pex.app.main.Message;

import pex.app.core.InterpreterHandler;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Display;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;
import pt.utl.ist.po.ui.InvalidOperation;

/**
 * Write (save) program to file.
 */
public class WriteProgram extends Command<InterpreterHandler> {
    /**
     * @param receiver
     */
    public WriteProgram(InterpreterHandler receiver) {
        super(Label.WRITE_PROGRAM, receiver);
    }

    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() {
        Form form = new Form();
        InputString inSProgID = new InputString(form, Message.requestProgramId());
        InputString inSFileName = new InputString(form, Message.programFileName());
        form.parse();
        try {
            entity().writeProgram(inSFileName.value, inSProgID.value);
        } catch (IOException) {

        }
    }
}
