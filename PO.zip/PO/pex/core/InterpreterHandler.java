package pex.app.core;

import pex.core.Interpreter;
import pex.app.main.App;
import pex.app.parser.NewParser;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.io.File;

public class InterpreterHandler{

	private Interpreter _interpreter;
	private App _app;
	private String _fileName = null;
	private Boolean _hasChanges = false;

	public InterpreterHandler(App app) {
		_app = app;
	}

	public Boolean getHasChanges() {
		return _hasChanges;
	}








	public void newInterpreter() {
		_interpreter = new Interpreter(_app);
		_hasChanges = true;
	}







	public void saveAsInterpreter() throws IOException{
		if (!_fileName.equals(null)) {
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(_fileName));
			out.writeObject(_interpreter);
			out.close();
			_hasChanges = false;
		}
		else throw new IOException();
	}

	public void saveAsInterpreter(String fileName) {
		File file = new File(fileName);
		file.createNewFile();
		_fileName = fileName;
		saveAsInterpreter();
	}






	public void openInterpreter(String fileName) throws FileNotFoundException {
		ObjectInputStream inob = new ObjectInputStream(new FileInputStream(fileName)); //throws FileNotFoundException automatically
		_interpreter = (Interpreter)inob.readObject();
		inob.close();
		_hasChanges = false;
	}







	public void createNewProgram(String programName) {
		_interpreter.createNewProgram(programName);
		_hasChanges = true;
	}








	public void readProgram(String programName) throws IOException{
		// pergunta ao ultilizador o nome do ficheiro ✓
		// ver se existe ✓
		// existindo passo o ficheiro para programa usando o parse file ✓
		// passo po interpretador o programa ✓
		if(fileName.exists) {
			Program program = NewParser.parseFile(programName + ".txt", programName); // ta mal
			_interpreter.addProgram(program);
		}
		
		else throw new IOException();
	}


	public void writeProgram(String fileName, String programName) {


	}







}