package pex.app.main;

import java.io.IOException;

import pex.core.InterpreterHandler;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputString;

/**
 * Save to file under current name (if unnamed, query for name).
 */
public class Save extends Command<InterpreterHandler> {
    /**
     * @param receiver
     */
    public Save(InterpreterHandler receiver) {
        super(Label.SAVE, receiver);
    }

    /** @see pt.utl.ist.po.ui.Command#execute() */
    @Override
    public final void execute() {

        try {
            entity().saveInterpreter();
        }
        catch(IOException io) {
            if(entity().getChange() == true) {
                Form form = new Form();
                InputString input = new InputString(form, Message.newSaveAs());
                form.parse();
                entity().saveAsInterpreter(input.value());
            }
        }
    }
}
