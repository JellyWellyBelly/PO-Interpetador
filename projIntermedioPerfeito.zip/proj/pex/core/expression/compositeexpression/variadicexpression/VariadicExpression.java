package pex.core.expression.compositeexpression.variadicexpression;

import pex.core.expression.Expression;
import pex.core.expression.compositeexpression.CompositeExpression;

import java.util.List;

public abstract class VariadicExpression extends CompositeExpression {
	
	private List<Expression> _expressions;

	public VariadicExpression(List<Expression> exps) {
		_expressions = exps;
	}

	public List<Expression> getArguments() {
		return _expressions;
	}

	public abstract String getAsText();
}