package pex.core.expression.compositeexpression;

import pex.core.expression.literal.Literal;

public class ReadI extends CompositeExpression {
	
	public ReadI() {

	}

	public String getAsText() {
		return "(readi)";
	}

	public Literal evaluate() {
		// do later
		return null;
	}
}