package pex.core.expression.compositeexpression;

import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public abstract class CompositeExpression extends Expression {
	
	public abstract String getAsText();

	public abstract Literal evaluate();
}