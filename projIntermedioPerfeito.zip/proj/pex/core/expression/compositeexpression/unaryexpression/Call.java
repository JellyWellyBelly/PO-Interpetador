package pex.core.expression.compositeexpression.unaryexpression;

import pex.core.Interpreter;
import pex.core.expression.Expression;
import pex.core.expression.literal.Literal;

public class Call extends UnaryExpression {

	private Interpreter _interpreter;

	public Call(Expression exp, Interpreter interpreter) {
		super(exp);
		_interpreter = interpreter;
	}

	public String getAsText() {
		return "(call " + super.getArgument().getAsText() + ")";
	}

	public Literal evaluate() {
		// do later
		return null;
	}
}