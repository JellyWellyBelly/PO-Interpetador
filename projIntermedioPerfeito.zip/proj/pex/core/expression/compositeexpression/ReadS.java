package pex.core.expression.compositeexpression;

import pex.core.expression.literal.Literal;

public class ReadS extends CompositeExpression {

	public ReadS() {
		
	}

	public String getAsText() {
		return "(reads)";
	}

	public Literal evaluate() {
		// do later
		return null;
	}
}