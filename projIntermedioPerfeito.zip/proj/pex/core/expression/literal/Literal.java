package pex.core.expression.literal;

import pex.core.expression.Expression;

public abstract class Literal extends Expression {
	
	public abstract String getAsText();

	public abstract Literal evaluate();
}